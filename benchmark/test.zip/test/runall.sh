node main.js -c teste10.json &&
node main.js -c teste02.json &&
node main.js -c teste03.json &&
node main.js -c teste04.json &&
node main.js -c teste05.json &&
node main.js -c teste06.json &&
node main.js -c teste07.json &&
node main.js -c teste08.json &&
node main.js -c teste09.json &&
node main.js -c teste10.json &&
node main.js -c teste11.json &&
node main.js -c teste12.json &&
node main.js -c teste13.json &&
node main.js -c teste14.json &&
node main.js -c teste15.json &&
node main.js -c teste16.json